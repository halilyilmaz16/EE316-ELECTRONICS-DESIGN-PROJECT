Version 4
SymbolType CELL
LINE Normal -32 -32 32 0
LINE Normal -32 32 32 0
LINE Normal -32 -32 -32 32
LINE Normal -20 -12 -12 -12
LINE Normal -16 -16 -16 -8
LINE Normal -20 12 -12 12
LINE Normal 0 11 0 48
LINE Normal 0 -12 0 -48
LINE Normal -48 -16 -26 -16
LINE Normal -48 16 -25 16
LINE Normal 48 0 32 0
WINDOW 3 24 25 Left 1
SYMATTR Value LM358
SYMATTR Prefix X
SYMATTR Description LM358 single op-amp symbol
SYMATTR ModelFile LM358.lib
PIN -48 -16 NONE 8
PINATTR PinName +
PINATTR SpiceOrder 1
PIN -48 16 NONE 8
PINATTR PinName -
PINATTR SpiceOrder 2
PIN 0 -48 NONE 8
PINATTR PinName V+
PINATTR SpiceOrder 3
PIN 0 48 NONE 8
PINATTR PinName V-
PINATTR SpiceOrder 4
PIN 48 0 NONE 8
PINATTR PinName OUT
PINATTR SpiceOrder 5

LM358 LTspice Package with Symbol

Files:
- LM358.lib : LM358-compatible op-amp SPICE model
- LM358.asy : LTspice symbol file

Recommended folder placement:
1. Copy LM358.lib to:
   Documents\LTspice\lib\sub

2. Copy LM358.asy to:
   Documents\LTspice\lib\sym

Alternative:
- Put both LM358.lib and LM358.asy in the same folder as your .asc circuit file.

In your LTspice schematic, add this SPICE directive:
.include LM358.lib

Symbol value:
LM358

Symbol pin order:
+ input   = SpiceOrder 1
- input   = SpiceOrder 2
V+ supply = SpiceOrder 3
V- supply = SpiceOrder 4
OUT       = SpiceOrder 5

For single-supply use:
- Connect V+ to +5 V, +9 V, +12 V, etc.
- Connect V- to GND.

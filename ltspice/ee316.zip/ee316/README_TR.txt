L298N LTspice - GRID16 DÜZELTİLMİŞ SÜRÜM
==========================================

Sorun
-----
Önceki sembolde bazı pinlerin Y koordinatları -88 ve 104 idi.
LTspice şema bağlantı ızgarası 16 birimdir.

-88 / 16 = tam sayı değildir.
104 / 16 = tam sayı değildir.

Bu nedenle tel imleci bazı pinlere kilitlenemiyordu.

Düzeltme
--------
Bütün pin bağlantı noktaları 16'nın katlarına taşındı:

OUT 1   : (352, -160)
OUT 2   : (352,  -96)
SENSE A : (352,  -32)

OUT 3   : (352,   64)
OUT 4   : (352,  128)
SENSE B : (352,  192)

Diğer bütün giriş, besleme ve GND pinleri de 16 birimlik grid üzerindedir.

Kullanım
--------
1. Eski L298N sembolünü şemadan sil.
2. Bu paketteki dosyaları aynı klasöre çıkar.
3. L298N_grid16_template.asc dosyasını aç veya F2 ile
   L298N_MW15_GRID16 sembolünü yeniden yerleştir.
4. Eski sembol önbellekte görünüyorsa LTspice'ı kapatıp yeniden aç.
5. Şemada şu directive bulunmalıdır:
       .include L298N_behavioral.lib

Elle düzeltmek için
-------------------
Eski .asy dosyasında:
    PIN 352 -88 RIGHT 16
satırını:
    PIN 352 -96 RIGHT 16
olarak değiştir.

Aynı şekilde -352 -88 koordinatını da -352 -96 yap.
104 kullanılan pinleri 128 veya 96 gibi 16'nın katı bir koordinata taşı.

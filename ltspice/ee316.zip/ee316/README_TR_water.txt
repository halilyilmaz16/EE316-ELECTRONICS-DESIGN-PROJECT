WATER PUMP LTspice PAKETİ
==========================

Bu paket, belirli bir marka/model yerine ayarlanabilir bir 12 V DC su
pompasını temsil eder.

DOSYALAR
--------
Water_Pump_12V.lib
    Elektriksel ve basitleştirilmiş mekanik pompa modeli.

WATER_PUMP_12V_2PIN.asy
    Yalnızca PUMP+ ve PUMP- uçları bulunan normal sembol.

WATER_PUMP_12V_MONITOR.asy
    Güç uçlarına ek olarak SPEED, FLOW ve HEAD izleme çıkışları bulunan
    sembol.

Water_Pump_template.asc
    Bütün bağlantıların dışarı çıkarıldığı hazır LTspice şeması.

Water_Pump_startup_test.cir
    12 V ile pompa başlangıç akımını, hızını, debisini ve basma
    yüksekliğini gösteren çalıştırılabilir test.

KURULUM
-------
1. ZIP dosyasını tek klasöre çıkar.
2. Water_Pump_template.asc dosyasını LTspice ile aç.
3. .asc, .asy ve .lib dosyalarını aynı klasörde tut.
4. Şemada şu komut bulunmalıdır:

       .include Water_Pump_12V.lib

KENDİ ŞEMANDA KULLANIM
----------------------
Normal iki uçlu pompa için:
    WATER_PUMP_12V_2PIN

İzleme çıkışlı pompa için:
    WATER_PUMP_12V_MONITOR

Varsayılan parametreler:
    VNOM=12       Nominal gerilim, V
    IRATED=1      Normal çalışma akımı, A
    ISTALL=5      Kalkış/kilitlenme akımı, A
    RPM=5000      Nominal hız, rpm
    LA=1m         Motor endüktansı, H
    J=5u          Mekanik atalet
    DAMP=10u      Mekanik sürtünme
    QNOM=5        Nominal debi, L/dakika
    HNOM=3        Nominal basma yüksekliği, metre

Örnek olarak 12 V, 2 A çalışan ve 8 A kalkış akımı olan bir pompa:
    VNOM=12 IRATED=2 ISTALL=8 RPM=4500 QNOM=10 HNOM=5

Bunu sembole sağ tıklayıp SpiceLine alanına yazabilirsin.

MONİTÖR ÇIKIŞLARI
-----------------
SPEED:
    1 V = 1000 rpm
    Örnek: 4.5 V, 4500 rpm anlamına gelir.

FLOW:
    1 V = 1 L/dakika
    Örnek: 5 V, 5 L/dakika anlamına gelir.

HEAD:
    1 V = 1 metre
    Örnek: 3 V, 3 metre anlamına gelir.

MODEL SINIRLARI
---------------
- Pompa yük momenti hızın karesiyle değişen basitleştirilmiş bir modeldir.
- Gerçek pompanın akım, debi ve basma yüksekliği değerlerini kullanmak için
  SpiceLine parametrelerini pompa datasheet'ine göre değiştirmelisin.
- Kuru çalışma, sıvı yoğunluğu, boru basınç kaybı, kavitasyon, sıcaklık,
  fırça arkı ve mekanik arıza ayrıntılı olarak modellenmez.
- L298 gibi bir sürücüyle kullanırken endüktif yük koruma diyotları gerçek
  devrede ayrıca bulunmalıdır.

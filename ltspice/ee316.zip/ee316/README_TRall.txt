EE316 - UNDEFINED SUBCIRCUIT DÜZELTMESİ
=========================================

Hata mesajları:
    This sub-circuit name is not defined: L298N
    This sub-circuit name is not defined: ACS712
    This sub-circuit name is not defined: WATER_PUMP_12V
    This sub-circuit name is not defined: pot

Bunların tamamı EE316_All_Models.lib dosyasına eklendi.

ADIM ADIM KURULUM
-----------------
1. EE316_All_Models.lib dosyasını ana .asc şemanın bulunduğu klasöre koy.

   Örnek klasör:
   C:\Users\halil\Documents\LTspice\

2. LTspice şemasında S tuşuna bas.
   Açılan SPICE Directive penceresine tam olarak şunu yaz:

       .include EE316_All_Models.lib

3. Bu satırı şema üzerine yerleştir.

4. Eski ayrı include satırlarını kaldırabilirsin:
       .include L298N_behavioral.lib
       .include ACS712_allpins.lib
       .include Water_Pump_12V.lib

   Tek birleşik include yeterlidir.

5. Normal metin aracıyla yazılmış .include çalışmaz.
   Satırın SPICE Directive olarak eklenmesi gerekir.

DOSYAYI BAŞKA KLASÖRDE TUTARSAN
-------------------------------
Tam yolu çift tırnakla kullan:

    .include "C:\Users\halil\Documents\LTspice\EE316_All_Models.lib"

SEMBOL AYARLARI
---------------
L298N:
    Prefix    = X
    Value     = L298N

ACS712:
    Prefix    = X
    Value     = ACS712
    SpiceLine = SENS=0.066
    (30 A sürümü için)

Water pump:
    Prefix    = X
    Value     = WATER_PUMP_12V
    SpiceLine = VNOM=12 IRATED=1 ISTALL=5 RPM=5000 QNOM=5 HNOM=3

Pot:
    Prefix    = X
    Value     = pot
    SpiceLine = Rtot=10K wiper=.5

KONTROL
-------
Simülasyonu tekrar çalıştırdıktan sonra View > SPICE Netlist seç.
Netlistin başlarında şu satırı görmelisin:

    .include EE316_All_Models.lib

Bu satır netlistte yoksa directive yanlışlıkla normal text olarak eklenmiştir.

NOT
---
X§U3, X§U5 gibi görünen karakterler LTspice'ın dahili sembol/netlist
gösterimidir. Undefined subcircuit hatasının sebebi değildir.
